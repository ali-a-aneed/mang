import jsPDF from 'jspdf';
import html2canvas from 'html2canvas';
import { REPORT_EXPORT_FIELDS, ReportExportFieldKey, ReportQueryResult } from '../types/reports';

function formatExportValue(row: any, key: ReportExportFieldKey, isArabic: boolean): string {
  if (!row) return '-';

  switch (key) {
    case 'taskCode':
      return row.taskCode || row.id || '-';
    case 'title':
      return row.title || '-';
    case 'companyName':
    case 'company':
      if (row.company && typeof row.company === 'object') {
        return (isArabic && row.company.nameAr ? row.company.nameAr : (row.company.nameEn || row.company.nameAr || '-'));
      }
      return row.companyName || row.companyNameAr || row.companyNameEn || '-';
    case 'status':
      if (row.status && typeof row.status === 'object') {
        return (isArabic ? row.status.nameAr : row.status.nameEn) || row.status.slug || '-';
      }
      if (isArabic) {
        if (row.statusLabelAr) return row.statusLabelAr;
        if (row.status === 'completed') return 'مكتملة';
        if (row.status === 'in_progress') return 'قيد التنفيذ';
        if (row.status === 'delayed') return 'متأخرة';
        if (row.status === 'paused') return 'متوقفة مؤقتاً';
        if (row.status === 'cancelled') return 'ملغاة';
        if (row.status === 'pending') return 'قيد الانتظار';
      }
      return row.statusLabelEn || row.status || '-';
    case 'priority':
      if (row.priority && typeof row.priority === 'object') {
        return (isArabic ? row.priority.nameAr : row.priority.nameEn) || row.priority.slug || '-';
      }
      if (isArabic) {
        if (row.priorityLabelAr) return row.priorityLabelAr;
        if (row.priority === 'vip') return 'VIP - أولوية قصوى';
        if (row.priority === 'high') return 'عالية';
        if (row.priority === 'medium') return 'متوسطة';
        if (row.priority === 'low') return 'منخفضة';
      }
      return row.priorityLabelEn || row.priority || '-';
    case 'assigneeName':
    case 'assignedTo':
      if (row.assignedTo && typeof row.assignedTo === 'object') {
        return (isArabic && row.assignedTo.fullNameAr ? row.assignedTo.fullNameAr : (row.assignedTo.fullName || '-'));
      }
      return row.assignedToName || row.assigneeName || (isArabic ? 'غير مسند' : 'Unassigned');
    case 'responsiblePersonId':
      if (row.responsiblePerson && typeof row.responsiblePerson === 'object') {
        return row.responsiblePerson.fullName || '-';
      }
      return row.responsiblePersonId || '-';
    case 'dueDate':
      return row.dueDate ? new Date(row.dueDate).toLocaleDateString(isArabic ? 'ar-SA' : 'en-US') : '-';
    case 'startDate':
      return row.startDate ? new Date(row.startDate).toLocaleDateString(isArabic ? 'ar-SA' : 'en-US') : '-';
    case 'completionDate':
      return row.completionDate ? new Date(row.completionDate).toLocaleDateString(isArabic ? 'ar-SA' : 'en-US') : '-';
    case 'estimatedHours':
      return row.estimatedHours ? `${row.estimatedHours}h` : '-';
    case 'actualHours':
      return row.actualHours ? `${row.actualHours}h` : '-';
    case 'description':
      return row.description || '-';
    case 'statusReason':
      return row.statusReason || '-';
    case 'creatorName':
    case 'creator':
      if (row.creator && typeof row.creator === 'object') {
        return row.creator.fullName || '-';
      }
      return row.creatorName || '-';
    case 'createdAt':
      return row.createdAt ? new Date(row.createdAt).toLocaleDateString(isArabic ? 'ar-SA' : 'en-US') : '-';
    case 'updatedAt':
      return row.updatedAt ? new Date(row.updatedAt).toLocaleDateString(isArabic ? 'ar-SA' : 'en-US') : '-';
    case 'customFields':
      if (row.customFields && typeof row.customFields === 'object') {
        return Object.entries(row.customFields)
          .map(([k, v]) => `${k}: ${v}`)
          .join(', ') || '-';
      }
      return '-';
    default: {
      const val = row[key];
      if (val === null || val === undefined) return '-';
      if (typeof val === 'object') return JSON.stringify(val);
      return String(val);
    }
  }
}

/**
 * Sanitizes cloned document for html2canvas to eliminate modern CSS colors like oklch()
 * which crash older/standard html2canvas CSS parsers.
 */
function sanitizeClonedDoc(clonedDoc: Document): void {
  try {
    const styles = clonedDoc.querySelectorAll('style, link[rel="stylesheet"]');
    styles.forEach((el) => {
      try {
        if (el.tagName.toLowerCase() === 'link') {
          // Remove remote stylesheet links to prevent CORS and unsupported css functions
          el.remove();
        } else if (el.textContent && el.textContent.includes('oklch')) {
          // Replace oklch(...) occurrences with safe hex fallback
          el.textContent = el.textContent.replace(/oklch\([^)]+\)/gi, '#475569');
        }
      } catch {
        // ignore
      }
    });

    // Check all elements in clonedDoc for any inline style with oklch
    const allElements = clonedDoc.querySelectorAll('*');
    allElements.forEach((el) => {
      const htmlEl = el as HTMLElement;
      if (htmlEl.style) {
        for (let i = 0; i < htmlEl.style.length; i++) {
          const prop = htmlEl.style[i];
          const val = htmlEl.style.getPropertyValue(prop);
          if (val && val.includes('oklch')) {
            htmlEl.style.setProperty(prop, '#334155');
          }
        }
      }
    });

    if (clonedDoc.documentElement) {
      clonedDoc.documentElement.style.backgroundColor = '#ffffff';
      clonedDoc.documentElement.style.color = '#0f172a';
    }
  } catch (e) {
    console.warn('CSS sanitization warning:', e);
  }
}

export async function generateReportPdf(
  reportData: ReportQueryResult,
  selectedFields: ReportExportFieldKey[],
  isArabic: boolean = false
): Promise<void> {
  const isAllCompanies = !reportData.filters?.companyId || reportData.filters.companyId === 'all';
  const selectedCompanyName = reportData.appliedFilters?.companyName || (isArabic ? 'جميع الشركات' : 'All Companies');
  
  const title = isArabic
    ? `تقرير المهام التشغيلية - ${selectedCompanyName}`
    : `Operations & Tasks Report - ${selectedCompanyName}`;

  const tasksList = reportData.tasks || reportData.data || [];
  const recordsCount = reportData.filteredCount || tasksList.length;

  const summary = reportData.summary || {
    totalTasks: recordsCount,
    completedTasks: tasksList.filter((t: any) => t.status === 'completed').length,
    inProgressTasks: tasksList.filter((t: any) => t.status === 'in_progress').length,
    delayedTasks: tasksList.filter((t: any) => t.status === 'delayed' || t.isDelayed).length,
    overdueTasks: tasksList.filter((t: any) => t.daysOverdue > 0).length,
  };

  const pausedCount = tasksList.filter((t: any) => t.status === 'paused').length;
  const cancelledCount = tasksList.filter((t: any) => t.status === 'cancelled').length;

  const subtitle = `${isArabic ? 'تاريخ التوليد:' : 'Generated on:'} ${new Date().toLocaleString(isArabic ? 'ar-SA' : 'en-US')} | ${
    isArabic ? 'إجمالي السجلات:' : 'Total Records:'
  } ${recordsCount}`;

  const activeFields = REPORT_EXPORT_FIELDS.filter((f) => selectedFields.includes(f.key));
  const tableData = tasksList;

  // Create isolated container with 100% inline CSS and standard HEX colors
  const container = document.createElement('div');
  container.id = 'pdf-render-virtual-container';
  container.style.position = 'fixed';
  container.style.left = '0';
  container.style.top = '0';
  container.style.zIndex = '-9999';
  container.style.opacity = '1';
  container.style.pointerEvents = 'none';
  container.style.width = '1280px';
  container.style.backgroundColor = '#ffffff';
  container.style.color = '#0f172a';
  container.style.padding = '32px';
  container.style.fontFamily = 'system-ui, -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, sans-serif';
  container.dir = isArabic ? 'rtl' : 'ltr';

  // Build HTML document structure
  let html = `
    <!-- Executive Header -->
    <div style="border-bottom: 2px solid #0f172a; padding-bottom: 14px; margin-bottom: 18px;">
      <div style="display: flex; justify-content: space-between; align-items: flex-start;">
        <div>
          <div style="font-size: 11px; font-weight: bold; color: #1d4ed8; text-transform: uppercase; margin-bottom: 3px;">
            ${isArabic ? 'وثيقة حوكمة تشغيلية رسمية معتمدة' : 'Official Executive Operations Document'}
          </div>
          <h1 style="font-size: 20px; font-weight: 800; color: #0f172a; margin: 0 0 4px 0;">${title}</h1>
          <p style="font-size: 12px; color: #475569; margin: 0;">${subtitle}</p>
        </div>
        <div style="text-align: ${isArabic ? 'left' : 'right'}; font-size: 11px; color: #64748b;">
          <div style="font-weight: bold; color: #0f172a; font-size: 12px;">${isArabic ? 'النظام المركزي لإدارة الشركات والمهام' : 'Central Enterprise Management'}</div>
          <div>${isArabic ? 'نطاق التقرير:' : 'Scope:'} <strong style="color: #1e293b;">${selectedCompanyName}</strong></div>
          <div>${isArabic ? 'نسخة مصدقة' : 'Verified Copy'}</div>
        </div>
      </div>
    </div>

    <!-- KPI Summary Section (NO PROGRESS %) -->
    <div style="display: grid; grid-template-columns: repeat(6, 1fr); gap: 10px; margin-bottom: 18px;">
      <div style="background-color: #f8fafc; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; text-align: center;">
        <div style="font-size: 10px; font-weight: bold; color: #475569; text-transform: uppercase;">${isArabic ? 'إجمالي المهام' : 'Total Tasks'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #0f172a; margin-top: 2px;">${summary.totalTasks}</div>
      </div>
      <div style="background-color: #eff6ff; border: 1px solid #bfdbfe; border-radius: 8px; padding: 10px; text-align: center;">
        <div style="font-size: 10px; font-weight: bold; color: #1d4ed8; text-transform: uppercase;">${isArabic ? 'قيد التنفيذ' : 'In Progress'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #1d4ed8; margin-top: 2px;">${summary.inProgressTasks}</div>
      </div>
      <div style="background-color: #fffbeb; border: 1px solid #fde68a; border-radius: 8px; padding: 10px; text-align: center;">
        <div style="font-size: 10px; font-weight: bold; color: #b45309; text-transform: uppercase;">${isArabic ? 'متأخرة' : 'Delayed'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #b45309; margin-top: 2px;">${summary.delayedTasks}</div>
      </div>
      <div style="background-color: #fff1f2; border: 1px solid #fecdd3; border-radius: 8px; padding: 10px; text-align: center;">
        <div style="font-size: 10px; font-weight: bold; color: #be123c; text-transform: uppercase;">${isArabic ? 'تجاوزت الاستحقاق' : 'Overdue'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #be123c; margin-top: 2px;">${summary.overdueTasks}</div>
      </div>
      <div style="background-color: #ecfdf5; border: 1px solid #a7f3d0; border-radius: 8px; padding: 10px; text-align: center;">
        <div style="font-size: 10px; font-weight: bold; color: #047857; text-transform: uppercase;">${isArabic ? 'المكتملة' : 'Completed'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #047857; margin-top: 2px;">${summary.completedTasks}</div>
      </div>
      <div style="background-color: #f1f5f9; border: 1px solid #cbd5e1; border-radius: 8px; padding: 10px; text-align: center;">
        <div style="font-size: 10px; font-weight: bold; color: #475569; text-transform: uppercase;">${isArabic ? 'معلقة / ملغاة' : 'Paused / Cancelled'}</div>
        <div style="font-size: 20px; font-weight: 900; color: #475569; margin-top: 2px;">${pausedCount + cancelledCount}</div>
      </div>
    </div>

    <!-- Visual Status Distribution Analytics Bar -->
    <div style="background-color: #f8fafc; border: 1px solid #e2e8f0; border-radius: 8px; padding: 12px; margin-bottom: 20px;">
      <div style="display: flex; justify-content: space-between; font-size: 11px; font-weight: bold; color: #334155; margin-bottom: 8px;">
        <span>${isArabic ? 'مخطط التوزيع الإحصائي لحالات المهام:' : 'Task Status Distribution:'}</span>
        <span>${isArabic ? `مجموع المهام: ${recordsCount}` : `Total Tasks: ${recordsCount}`}</span>
      </div>
      <div style="height: 14px; border-radius: 7px; overflow: hidden; display: flex; background-color: #e2e8f0;">
        ${recordsCount > 0 ? `
          <div style="width: ${(summary.completedTasks / recordsCount) * 100}%; background-color: #10b981;" title="Completed"></div>
          <div style="width: ${(summary.inProgressTasks / recordsCount) * 100}%; background-color: #3b82f6;" title="In Progress"></div>
          <div style="width: ${(summary.delayedTasks / recordsCount) * 100}%; background-color: #f59e0b;" title="Delayed"></div>
          <div style="width: ${(summary.overdueTasks / recordsCount) * 100}%; background-color: #ef4444;" title="Overdue"></div>
          <div style="width: ${(pausedCount / recordsCount) * 100}%; background-color: #94a3b8;" title="Paused"></div>
          <div style="width: ${(cancelledCount / recordsCount) * 100}%; background-color: #64748b;" title="Cancelled"></div>
        ` : `<div style="width: 100%; background-color: #cbd5e1;"></div>`}
      </div>
      <div style="display: flex; gap: 14px; margin-top: 8px; font-size: 10px; color: #475569; flex-wrap: wrap;">
        <span style="display: inline-flex; align-items: center; gap: 4px;">
          <span style="width: 8px; height: 8px; background-color: #10b981; border-radius: 2px;"></span>
          ${isArabic ? 'مكتملة' : 'Completed'} (${summary.completedTasks})
        </span>
        <span style="display: inline-flex; align-items: center; gap: 4px;">
          <span style="width: 8px; height: 8px; background-color: #3b82f6; border-radius: 2px;"></span>
          ${isArabic ? 'قيد التنفيذ' : 'In Progress'} (${summary.inProgressTasks})
        </span>
        <span style="display: inline-flex; align-items: center; gap: 4px;">
          <span style="width: 8px; height: 8px; background-color: #f59e0b; border-radius: 2px;"></span>
          ${isArabic ? 'متأخرة' : 'Delayed'} (${summary.delayedTasks})
        </span>
        <span style="display: inline-flex; align-items: center; gap: 4px;">
          <span style="width: 8px; height: 8px; background-color: #ef4444; border-radius: 2px;"></span>
          ${isArabic ? 'حرجة / تجاوزت الاستحقاق' : 'Overdue'} (${summary.overdueTasks})
        </span>
        <span style="display: inline-flex; align-items: center; gap: 4px;">
          <span style="width: 8px; height: 8px; background-color: #94a3b8; border-radius: 2px;"></span>
          ${isArabic ? 'معلقة' : 'Paused'} (${pausedCount})
        </span>
      </div>
    </div>

    <!-- Data Table -->
    <table style="width: 100%; border-collapse: collapse; font-size: 11px; text-align: ${isArabic ? 'right' : 'left'};">
      <thead>
        <tr>
          ${activeFields
            .map(
              (f) =>
                `<th style="background-color: #1e293b; color: #ffffff; padding: 9px 8px; border: 1px solid #cbd5e1; font-weight: bold;">${
                  isArabic ? f.labelAr : f.labelEn
                }</th>`
            )
            .join('')}
        </tr>
      </thead>
      <tbody>
        ${
          tableData.length === 0
            ? `<tr><td colspan="${activeFields.length}" style="padding: 24px; text-align: center; color: #94a3b8;">${
                isArabic ? 'لا توجد بيانات مطابقة لخيارات التصفية' : 'No records found matching filters'
              }</td></tr>`
            : tableData
                .map((row: any, i: number) => {
                  const bg = i % 2 === 0 ? '#ffffff' : '#f8fafc';
                  return `<tr style="background-color: ${bg};">
            ${activeFields
              .map((f) => {
                const formattedVal = formatExportValue(row, f.key, isArabic);
                return `<td style="padding: 7px 6px; border: 1px solid #cbd5e1; color: #334155; vertical-align: top; word-break: break-word;">${formattedVal}</td>`;
              })
              .join('')}
          </tr>`;
                })
                .join('')
        }
      </tbody>
    </table>

    <!-- Footer -->
    <div style="margin-top: 24px; padding-top: 12px; border-top: 1px solid #e2e8f0; display: flex; justify-content: space-between; font-size: 10px; color: #94a3b8;">
      <span>${isArabic ? 'تم الإصدار آلياً بواسطة المنظومة المركزية لحوكمة الشركات' : 'Generated automatically by Enterprise Governance System'}</span>
      <span>${isArabic ? 'وثيقة حوكمة رسمية' : 'Official Report Document'}</span>
    </div>
  `;

  container.innerHTML = html;
  document.body.appendChild(container);

  try {
    const canvas = await html2canvas(container, {
      scale: 2,
      useCORS: true,
      logging: false,
      windowWidth: 1280,
      scrollX: 0,
      scrollY: 0,
      onclone: sanitizeClonedDoc,
    });

    const imgData = canvas.toDataURL('image/png');
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 10;
    const contentWidth = pageWidth - margin * 2;
    const contentHeight = (canvas.height * contentWidth) / canvas.width;

    let heightLeft = contentHeight;
    let position = margin;

    // First page
    doc.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
    heightLeft -= (pageHeight - margin * 2);

    // Multi-page handling
    while (heightLeft > 0) {
      position = heightLeft - contentHeight + margin;
      doc.addPage();
      doc.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
      heightLeft -= (pageHeight - margin * 2);
    }

    const safeDate = new Date().toISOString().substring(0, 10);
    const cleanCompName = selectedCompanyName.replace(/[^\w\s\u0600-\u06FF]/gi, '').trim().replace(/\s+/g, '_');
    doc.save(`Operations_Report_${cleanCompName}_${safeDate}.pdf`);
  } catch (err) {
    console.error('PDF Generation error caught, applying fallback print:', err);
    window.print();
  } finally {
    if (document.body.contains(container)) {
      document.body.removeChild(container);
    }
  }
}

/**
 * Exports a specific DOM element (like Company Analysis dashboard) to a multi-page PDF document
 */
export async function exportElementToPdf(
  element: HTMLElement,
  fileName: string = 'Company_Analysis_Report',
  isArabic: boolean = false
): Promise<void> {
  try {
    const canvas = await html2canvas(element, {
      scale: 2,
      useCORS: true,
      logging: false,
      scrollX: 0,
      scrollY: 0,
      onclone: sanitizeClonedDoc,
    });

    const imgData = canvas.toDataURL('image/png');
    const doc = new jsPDF({ orientation: 'landscape', unit: 'mm', format: 'a4' });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 8;
    const contentWidth = pageWidth - margin * 2;
    const contentHeight = (canvas.height * contentWidth) / canvas.width;

    let heightLeft = contentHeight;
    let position = margin;

    doc.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
    heightLeft -= (pageHeight - margin * 2);

    while (heightLeft > 0) {
      position = heightLeft - contentHeight + margin;
      doc.addPage();
      doc.addImage(imgData, 'PNG', margin, position, contentWidth, contentHeight, undefined, 'FAST');
      heightLeft -= (pageHeight - margin * 2);
    }

    const safeDate = new Date().toISOString().substring(0, 10);
    doc.save(`${fileName}_${safeDate}.pdf`);
  } catch (err) {
    console.error('Export element to PDF failed:', err);
    window.print();
  }
}
